# American Life English — Starter v0.2.0

Native Android app built with Kotlin and Jetpack Compose.

## Version 0.2.0
- Expanded the starter vocabulary from 4 sample entries to a curated initial set covering study, employment, housing, healthcare, and everyday life in the United States.
- Search now also checks Persian pronunciation and word-family entries.
- Home screen uses vertical scrolling so all learning cards remain reachable on smaller screens.
- Android versionCode/versionName updated to 2 / 0.2.0.

## Important content note
This is an early content release, not the promised complete 10,000-entry dictionary. The 10,000 figure is a long-term target for distinct headwords. Word forms and related terms should be linked to headwords rather than counted as separate vocabulary entries. Each entry must be reviewed for American usage and accuracy before the dictionary is considered complete.

## Build
Open in Android Studio and build the `app` module, or use the repository GitHub Actions workflow to create a debug APK.
