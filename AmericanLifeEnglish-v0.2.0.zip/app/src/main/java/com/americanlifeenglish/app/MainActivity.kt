package com.americanlifeenglish.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF142B4A)
private val Blue = Color(0xFF2878D0)
private val Sky = Color(0xFFEAF3FF)
private val Coral = Color(0xFFFF765E)
private val Mint = Color(0xFFE5F7F0)
private val Ink = Color(0xFF203047)

data class Word(
    val word: String, val ipa: String, val persianSound: String, val pos: String,
    val meaning: String, val definition: String, val example: String, val exampleFa: String,
    val family: List<Pair<String,String>>, val synonyms: List<Pair<String,String>>,
    val antonyms: List<Pair<String,String>>
)

private val words = listOf(
    Word("create", "/kriˈeɪt/", "کری‌اِیت", "verb", "ایجاد کردن؛ خلق کردن",
        "To make something new or bring something into existence.",
        "I want to create a useful app.", "می‌خواهم یک برنامه کاربردی بسازم.",
        listOf("creation" to "آفرینش؛ ایجاد", "creator" to "سازنده؛ خالق", "creative" to "خلاق", "creativity" to "خلاقیت", "creatively" to "به‌شکلی خلاقانه"),
        listOf("make" to "ساختن؛ ایجاد کردن", "produce" to "تولید کردن", "develop" to "توسعه دادن"),
        listOf("destroy" to "ویران کردن")),
    Word("reliable", "/rɪˈlaɪəbəl/", "ری‌لایِبِل", "adjective", "قابل اعتماد",
        "Able to be trusted or depended on.",
        "She's a reliable coworker.", "او همکار قابل اعتمادی است.",
        listOf("rely" to "اتکا کردن", "reliability" to "قابلیت اعتماد", "reliably" to "به‌طور قابل اعتماد"),
        listOf("dependable" to "قابل اتکا", "trustworthy" to "امین؛ قابل اعتماد"),
        listOf("unreliable" to "غیرقابل اعتماد")),
    Word("affordable", "/əˈfɔːrdəbəl/", "اَفوردِبِل", "adjective", "مقرون‌به‌صرفه",
        "Not too expensive; something you have enough money to pay for.",
        "We're looking for an affordable apartment.", "دنبال یک آپارتمان مقرون‌به‌صرفه هستیم.",
        listOf("afford" to "توان مالی داشتن", "affordability" to "مقرون‌به‌صرفه بودن"),
        listOf("reasonable" to "معقول؛ مناسب", "budget-friendly" to "مناسب بودجه"),
        listOf("expensive" to "گران")),
    Word("appointment", "/əˈpɔɪntmənt/", "اَپوینت‌مِنت", "noun", "قرار ملاقات؛ وقت قبلی",
        "An arrangement to meet someone at a particular time.",
        "I have a doctor's appointment tomorrow.", "فردا از پزشک وقت دارم.",
        listOf("appoint" to "منصوب کردن؛ تعیین کردن", "appointed" to "تعیین‌شده"),
        listOf("meeting" to "جلسه؛ ملاقات", "booking" to "رزرو؛ وقت‌گیری"),
        listOf()),
    Word("application", "/ˌæplɪˈkeɪʃən/", "اَپلیکِیشِن", "noun", "درخواست؛ فرم درخواست؛ برنامه کاربردی",
        "A formal request for something, such as a job or a place at a school.",
        "I submitted my college application yesterday.", "دیروز درخواست پذیرش کالج را ارسال کردم.",
        listOf("apply" to "درخواست دادن", "applicant" to "متقاضی", "applicable" to "قابل اعمال"),
        listOf("request" to "درخواست", "form" to "فرم"), listOf()),
    Word("resume", "/ˈrezəmeɪ/", "رِزومِی", "noun", "رزومه؛ سابقه کاری و تحصیلی",
        "A document that summarizes your education, skills, and work experience.",
        "Please attach your resume to the application.", "لطفاً رزومه‌تان را به درخواست پیوست کنید.",
        listOf("résumé" to "رزومه"), listOf("CV" to "شرح سوابق"), listOf()),
    Word("interview", "/ˈɪntərvjuː/", "اینتِرویو", "noun / verb", "مصاحبه؛ مصاحبه کردن",
        "A formal meeting in which someone is asked questions for a job or school.",
        "My job interview is on Thursday.", "مصاحبه شغلی من پنجشنبه است.",
        listOf("interviewer" to "مصاحبه‌کننده", "interviewee" to "مصاحبه‌شونده"),
        listOf("meeting" to "جلسه"), listOf()),
    Word("deadline", "/ˈdedlaɪn/", "دِدلاین", "noun", "مهلت نهایی؛ ضرب‌الاجل",
        "The latest time or date by which something must be finished.",
        "The application deadline is March 1.", "مهلت نهایی درخواست اول مارس است.",
        listOf(), listOf("due date" to "تاریخ سررسید"), listOf()),
    Word("tuition", "/tuˈɪʃən/", "توئیشن", "noun", "شهریه؛ هزینه آموزش",
        "The money paid for instruction at a school, college, or university.",
        "Tuition is expensive at private universities.", "شهریه در دانشگاه‌های خصوصی گران است.",
        listOf("tuition-free" to "بدون شهریه"), listOf(), listOf()),
    Word("scholarship", "/ˈskɑːlərʃɪp/", "اسکالِرشیپ", "noun", "بورسیه؛ کمک‌هزینه تحصیلی",
        "Money awarded to a student to help pay for education.",
        "She received a scholarship for graduate school.", "او برای تحصیلات تکمیلی بورسیه گرفت.",
        listOf("scholar" to "پژوهشگر؛ دانشمند"), listOf("grant" to "کمک‌هزینه"), listOf()),
    Word("assignment", "/əˈsaɪnmənt/", "اِساینمِنت", "noun", "تکلیف؛ پروژه محول‌شده",
        "A task or piece of work given to a student or employee.",
        "I have to finish this assignment tonight.", "باید امشب این تکلیف را تمام کنم.",
        listOf("assign" to "محول کردن", "assigned" to "محول‌شده"), listOf("task" to "وظیفه"), listOf()),
    Word("landlord", "/ˈlændlɔːrd/", "لَندلورد", "noun", "صاحب‌خانه؛ موجر",
        "A person or company that rents a home or property to someone.",
        "The landlord fixed the heating system.", "صاحب‌خانه سیستم گرمایش را تعمیر کرد.",
        listOf(), listOf("property owner" to "مالک ملک"), listOf("tenant" to "مستأجر")),
    Word("tenant", "/ˈtenənt/", "تِنِنت", "noun", "مستأجر",
        "A person who pays rent to live in or use a property.",
        "The tenant pays rent on the first of each month.", "مستأجر اول هر ماه اجاره می‌پردازد.",
        listOf("tenancy" to "اجاره‌نشینی"), listOf("renter" to "اجاره‌کننده"), listOf("landlord" to "موجر")),
    Word("lease", "/liːs/", "لیس", "noun / verb", "قرارداد اجاره؛ اجاره کردن",
        "A legal agreement to use a property for a period of time in exchange for rent.",
        "I signed a one-year lease.", "من قرارداد اجاره یک‌ساله امضا کردم.",
        listOf("lessee" to "اجاره‌کننده", "lessor" to "اجاره‌دهنده"), listOf("rental agreement" to "قرارداد اجاره"), listOf()),
    Word("insurance", "/ɪnˈʃʊrəns/", "اینشورِنس", "noun", "بیمه",
        "An agreement that provides financial protection against certain losses.",
        "Does this job offer health insurance?", "آیا این شغل بیمه درمانی ارائه می‌دهد؟",
        listOf("insure" to "بیمه کردن", "insured" to "بیمه‌شده", "insurer" to "شرکت بیمه"),
        listOf("coverage" to "پوشش بیمه‌ای"), listOf()),
    Word("prescription", "/prɪˈskrɪpʃən/", "پریسکریپشِن", "noun", "نسخه پزشکی؛ تجویز",
        "A written order from a medical professional for medicine or treatment.",
        "The pharmacy needs your prescription.", "داروخانه به نسخه شما نیاز دارد.",
        listOf("prescribe" to "تجویز کردن", "prescribed" to "تجویزشده"), listOf("doctor's order" to "دستور پزشک"), listOf()),
    Word("symptom", "/ˈsɪmptəm/", "سیمپتِم", "noun", "علامت؛ نشانه بیماری",
        "A physical or mental change that may indicate an illness.",
        "A fever can be a symptom of infection.", "تب می‌تواند نشانه عفونت باشد.",
        listOf("symptomatic" to "دارای علامت"), listOf("sign" to "نشانه"), listOf()),
    Word("emergency", "/ɪˈmɜːrdʒənsi/", "ایمِرجِنسی", "noun", "وضعیت اضطراری؛ فوریت",
        "A serious situation that needs immediate action.",
        "Call 911 in a life-threatening emergency.", "در وضعیت تهدیدکننده حیات با ۹۱۱ تماس بگیرید.",
        listOf("emergency room" to "اورژانس بیمارستان", "emergency services" to "خدمات فوریت‌ها"),
        listOf("crisis" to "بحران"), listOf()),
    Word("benefit", "/ˈbenɪfɪt/", "بِنِفیت", "noun / verb", "مزیت؛ مزایا؛ بهره‌مند شدن",
        "An advantage or a helpful service provided to employees or members.",
        "The company offers health and dental benefits.", "شرکت مزایای بیمه درمانی و دندان‌پزشکی ارائه می‌دهد.",
        listOf("beneficial" to "سودمند", "beneficiary" to "ذی‌نفع"), listOf("advantage" to "مزیت"), listOf("drawback" to "عیب")),
    Word("salary", "/ˈsæləri/", "سَلِری", "noun", "حقوق؛ دستمزد ثابت",
        "A fixed amount of money paid regularly for a job.",
        "The position offers a competitive salary.", "این موقعیت شغلی حقوق رقابتی دارد.",
        listOf("salaried" to "حقوق‌بگیر"), listOf("pay" to "حقوق؛ پرداخت"), listOf()),
    Word("colleague", "/ˈkɑːliːɡ/", "کالیگ", "noun", "همکار",
        "A person you work with, especially in a professional job.",
        "I'll discuss the report with my colleagues.", "گزارش را با همکارانم بررسی می‌کنم.",
        listOf(), listOf("coworker" to "همکار"), listOf()),
    Word("schedule", "/ˈskedʒuːl/", "سکِجول", "noun / verb", "برنامه زمانی؛ زمان‌بندی کردن",
        "A plan that shows when activities or events will happen.",
        "My work schedule changes every week.", "برنامه کاری من هر هفته تغییر می‌کند.",
        listOf("scheduled" to "برنامه‌ریزی‌شده", "scheduling" to "زمان‌بندی"), listOf("timetable" to "جدول زمانی"), listOf()),
    Word("deposit", "/dɪˈpɑːzɪt/", "دیپازیت", "noun / verb", "ودیعه؛ سپرده؛ واریز کردن",
        "Money paid into an account or paid in advance as security.",
        "The apartment requires a security deposit.", "این آپارتمان به ودیعه ضمانتی نیاز دارد.",
        listOf("depositor" to "سپرده‌گذار"), listOf("down payment" to "پیش‌پرداخت"), listOf()),
    Word("commute", "/kəˈmjuːt/", "کِمیوت", "noun / verb", "رفت‌وآمد روزانه به محل کار یا تحصیل",
        "To travel regularly between home and work or school.",
        "I commute by train every morning.", "من هر روز صبح با قطار رفت‌وآمد می‌کنم.",
        listOf("commuter" to "فردی که رفت‌وآمد روزانه دارد"), listOf("travel to work" to "رفتن به محل کار"), listOf()),
    Word("available", "/əˈveɪləbəl/", "اَوِیلِبِل", "adjective", "در دسترس؛ موجود؛ آزاد",
        "Able to be used, obtained, or reached; free to do something.",
        "Are you available for an interview tomorrow?", "آیا فردا برای مصاحبه وقت دارید؟",
        listOf("availability" to "دسترس‌پذیری"), listOf("free" to "آزاد"), listOf("unavailable" to "غیرقابل دسترس")),
    Word("requirement", "/rɪˈkwaɪərmənt/", "ریکوایِرمِنت", "noun", "شرط؛ الزام؛ پیش‌نیاز",
        "Something that is needed or demanded.",
        "A bachelor's degree is a job requirement.", "مدرک کارشناسی یکی از شرایط این شغل است.",
        listOf("require" to "نیاز داشتن؛ الزام کردن", "required" to "الزامی"), listOf("condition" to "شرط"), listOf()),
    Word("eligible", "/ˈelɪdʒəbəl/", "اِلِجِبِل", "adjective", "واجد شرایط؛ دارای صلاحیت",
        "Meeting the conditions needed to do or receive something.",
        "You may be eligible for financial aid.", "ممکن است واجد شرایط کمک مالی باشید.",
        listOf("eligibility" to "واجد شرایط بودن"), listOf("qualified" to "دارای صلاحیت"), listOf("ineligible" to "فاقد شرایط")),

)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmericanLifeApp() }
    }
}

@Composable
fun AmericanLifeApp() {
    var section by remember { mutableStateOf("خانه") }
    var selectedWord by remember { mutableStateOf<Word?>(null) }
    var query by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color(0xFFF6F8FC))) {
        Scaffold(
            containerColor = Color(0xFFF6F8FC),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("خانه", "لغات", "گرامر", "مکالمه", "پیشرفت").forEach { item ->
                        NavigationBarItem(
                            selected = section == item,
                            onClick = { section = item; selectedWord = null },
                            icon = { Icon(when(item) {
                                "خانه" -> Icons.Default.Home
                                "لغات" -> Icons.Default.MenuBook
                                "گرامر" -> Icons.Default.School
                                "مکالمه" -> Icons.Default.Chat
                                else -> Icons.Default.Insights
                            }, contentDescription = item) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selectedWord != null) {
                    WordDetail(selectedWord!!) { selectedWord = null }
                } else when(section) {
                    "لغات" -> VocabularyScreen(query, { query = it }, { selectedWord = it })
                    "گرامر" -> GrammarScreen()
                    "مکالمه" -> PlaceholderScreen("مکالمات آمریکایی", "مکالمه‌های واقعی برای خرید، کار، تحصیل و زندگی روزمره.")
                    "پیشرفت" -> PlaceholderScreen("مسیر یادگیری شما", "پیشرفت، لغات ذخیره‌شده و مرورهای روزانه در نسخه‌های بعدی تکمیل می‌شوند.")
                    else -> HomeScreen { section = it }
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String = "") {
    Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("🇺🇸  AMERICAN LIFE ENGLISH", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Color(0xFFD8E6F8), fontSize = 13.sp)
        }
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("یادگیری انگلیسی برای زندگی واقعی", "از اولین کلمه تا تحصیل، کار و زندگی در آمریکا")
        Column(Modifier.padding(16.dp)) {
            Text("از کجا شروع کنیم؟", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            val tiles = listOf(
                Triple("📚", "فرهنگ لغت جامع", "لغات، خانواده کلمات، مترادف و متضاد" to "لغات"),
                Triple("📖", "آکادمی گرامر", "آموزش از پایه تا پیشرفته" to "گرامر"),
                Triple("💬", "مکالمات آمریکایی", "موقعیت‌های واقعی روزمره" to "مکالمه"),
                Triple("🎯", "پیشرفت و مرور", "تمرین و پیگیری یادگیری" to "پیشرفت")
            )
            tiles.forEach { tile ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onOpen(tile.third.second) },
                    shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tile.first, fontSize = 30.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tile.second, fontWeight = FontWeight.Bold, color = Ink, fontSize = 17.sp)
                            Text(tile.third.first, color = Color.Gray, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Blue)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Sky), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("روش یادگیری ما", fontWeight = FontWeight.Bold, color = Navy)
                    Text("هر مدخل شامل تلفظ آمریکایی، معنی فارسی، تعریف ساده انگلیسی، مثال، خانواده کلمات، مترادف‌ها و متضادهاست.",
                        color = Ink, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun VocabularyScreen(query: String, onQuery: (String) -> Unit, onSelect: (Word) -> Unit) {
    Column {
        Header("فرهنگ لغت", "جستجو در واژگان کاربردی انگلیسی آمریکایی")
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text("جستجوی انگلیسی یا معنی فارسی") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            items(words.filter { query.isBlank() || it.word.contains(query, true) || it.meaning.contains(query) || it.persianSound.contains(query) || it.family.any { f -> f.first.contains(query, true) || f.second.contains(query) } }) { word ->
                Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onSelect(word) },
                    colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(word.word, color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text(word.meaning, color = Ink, fontSize = 14.sp)
                            Text("${word.pos}  •  ${word.ipa}", color = Blue, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Blue)
                    }
                }
            }
        }
    }
}

@Composable
fun WordDetail(word: Word, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(16.dp))
            Text("جزئیات واژه", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.padding(16.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Sky), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(word.word.uppercase(), color = Navy, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("${word.ipa}   •   ${word.persianSound}", color = Blue)
                        Text("${word.pos}  |  ${word.meaning}", color = Ink, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(word.definition, color = Ink)
                        Spacer(Modifier.height(12.dp))
                        Text(word.example, color = Navy, fontWeight = FontWeight.Bold)
                        Text(word.exampleFa, color = Ink)
                    }
                }
            }
            item { RelationSection("خانواده کلمات (Word Family)", word.family, Mint) }
            item { RelationSection("مترادف‌ها (Synonyms)", word.synonyms, Color(0xFFFFF1E8)) }
            item { RelationSection("متضادها (Antonyms)", word.antonyms, Color(0xFFFFE9ED)) }
        }
    }
}

@Composable
fun RelationSection(title: String, entries: List<Pair<String,String>>, bg: Color) {
    if (entries.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp)) {
                Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                entries.forEach { (term, meaning) ->
                    Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(term, color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(meaning, color = Ink, textAlign = TextAlign.End)
                    }
                }
            }
        }
    }
}

@Composable
fun GrammarScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("آکادمی گرامر", "آموزش مرحله‌به‌مرحله از صفر تا پیشرفته")
        val lessons = listOf(
            "01  ساختار جمله در انگلیسی" to "Sentence Structure",
            "02  ضمایر و فعل to be" to "Pronouns & Be",
            "03  حال ساده" to "Present Simple",
            "04  حال استمراری" to "Present Continuous",
            "05  گذشته ساده" to "Past Simple",
            "06  آینده و شکل‌های بیان آینده" to "Future Forms",
            "07  حروف اضافه پرکاربرد" to "Prepositions",
            "08  افعال کمکی" to "Modal Verbs",
            "09  جملات شرطی" to "Conditionals",
            "10  مجهول" to "Passive Voice"
        )
        LazyColumn(Modifier.padding(16.dp)) {
            items(lessons) { lesson ->
                Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("📘", fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(lesson.first, color = Ink, fontWeight = FontWeight.Bold)
                            Text(lesson.second, color = Blue, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, description: String) {
    Column(Modifier.fillMaxSize()) {
        Header(title)
        Card(Modifier.padding(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Text(description, Modifier.padding(20.dp), color = Ink)
        }
    }
}
