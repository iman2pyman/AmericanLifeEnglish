package com.americanlifeenglish.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF142B4A)
private val Blue = Color(0xFF2878D0)
private val Sky = Color(0xFFEAF3FF)
private val Coral = Color(0xFFFF765E)
private val Mint = Color(0xFFE5F7F0)
private val Ink = Color(0xFF203047)

data class Word(
    val word: String, val ipa: String, val persianSound: String, val pos: String,
    val meaning: String, val definition: String, val example: String, val exampleFa: String,
    val family: List<Pair<String,String>>, val synonyms: List<Pair<String,String>>,
    val antonyms: List<Pair<String,String>>
)

private val words = listOf(
    Word("create", "/kriˈeɪt/", "کری‌اِیت", "verb", "ایجاد کردن؛ خلق کردن",
        "To make something new or bring something into existence.",
        "I want to create a useful app.", "می‌خواهم یک برنامه کاربردی بسازم.",
        listOf("creation" to "آفرینش؛ ایجاد", "creator" to "سازنده؛ خالق", "creative" to "خلاق", "creativity" to "خلاقیت", "creatively" to "به‌شکلی خلاقانه"),
        listOf("make" to "ساختن؛ ایجاد کردن", "produce" to "تولید کردن", "develop" to "توسعه دادن"),
        listOf("destroy" to "ویران کردن")),
    Word("reliable", "/rɪˈlaɪəbəl/", "ری‌لایِبِل", "adjective", "قابل اعتماد",
        "Able to be trusted or depended on.",
        "She's a reliable coworker.", "او همکار قابل اعتمادی است.",
        listOf("rely" to "اتکا کردن", "reliability" to "قابلیت اعتماد", "reliably" to "به‌طور قابل اعتماد"),
        listOf("dependable" to "قابل اتکا", "trustworthy" to "امین؛ قابل اعتماد"),
        listOf("unreliable" to "غیرقابل اعتماد")),
    Word("affordable", "/əˈfɔːrdəbəl/", "اَفوردِبِل", "adjective", "مقرون‌به‌صرفه",
        "Not too expensive; something you have enough money to pay for.",
        "We're looking for an affordable apartment.", "دنبال یک آپارتمان مقرون‌به‌صرفه هستیم.",
        listOf("afford" to "توان مالی داشتن", "affordability" to "مقرون‌به‌صرفه بودن"),
        listOf("reasonable" to "معقول؛ مناسب", "budget-friendly" to "مناسب بودجه"),
        listOf("expensive" to "گران")),
    Word("appointment", "/əˈpɔɪntmənt/", "اَپوینت‌مِنت", "noun", "قرار ملاقات؛ وقت قبلی",
        "An arrangement to meet someone at a particular time.",
        "I have a doctor's appointment tomorrow.", "فردا از پزشک وقت دارم.",
        listOf("appoint" to "منصوب کردن؛ تعیین کردن", "appointed" to "تعیین‌شده"),
        listOf("meeting" to "جلسه؛ ملاقات", "booking" to "رزرو؛ وقت‌گیری"),
        listOf())
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmericanLifeApp() }
    }
}

@Composable
fun AmericanLifeApp() {
    var section by remember { mutableStateOf("خانه") }
    var selectedWord by remember { mutableStateOf<Word?>(null) }
    var query by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color(0xFFF6F8FC))) {
        Scaffold(
            containerColor = Color(0xFFF6F8FC),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("خانه", "لغات", "گرامر", "مکالمه", "پیشرفت").forEach { item ->
                        NavigationBarItem(
                            selected = section == item,
                            onClick = { section = item; selectedWord = null },
                            icon = { Icon(when(item) {
                                "خانه" -> Icons.Default.Home
                                "لغات" -> Icons.Default.MenuBook
                                "گرامر" -> Icons.Default.School
                                "مکالمه" -> Icons.Default.Chat
                                else -> Icons.Default.Insights
                            }, contentDescription = item) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selectedWord != null) {
                    WordDetail(selectedWord!!) { selectedWord = null }
                } else when(section) {
                    "لغات" -> VocabularyScreen(query, { query = it }, { selectedWord = it })
                    "گرامر" -> GrammarScreen()
                    "مکالمه" -> PlaceholderScreen("مکالمات آمریکایی", "مکالمه‌های واقعی برای خرید، کار، تحصیل و زندگی روزمره.")
                    "پیشرفت" -> PlaceholderScreen("مسیر یادگیری شما", "پیشرفت، لغات ذخیره‌شده و مرورهای روزانه در نسخه‌های بعدی تکمیل می‌شوند.")
                    else -> HomeScreen { section = it }
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String = "") {
    Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("🇺🇸  AMERICAN LIFE ENGLISH", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Color(0xFFD8E6F8), fontSize = 13.sp)
        }
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("یادگیری انگلیسی برای زندگی واقعی", "از اولین کلمه تا تحصیل، کار و زندگی در آمریکا")
        Column(Modifier.padding(16.dp)) {
            Text("از کجا شروع کنیم؟", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            val tiles = listOf(
                Triple("📚", "فرهنگ لغت جامع", "لغات، خانواده کلمات، مترادف و متضاد" to "لغات"),
                Triple("📖", "آکادمی گرامر", "آموزش از پایه تا پیشرفته" to "گرامر"),
                Triple("💬", "مکالمات آمریکایی", "موقعیت‌های واقعی روزمره" to "مکالمه"),
                Triple("🎯", "پیشرفت و مرور", "تمرین و پیگیری یادگیری" to "پیشرفت")
            )
            tiles.forEach { tile ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onOpen(tile.third.second) },
                    shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tile.first, fontSize = 30.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tile.second, fontWeight = FontWeight.Bold, color = Ink, fontSize = 17.sp)
                            Text(tile.third.first, color = Color.Gray, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Blue)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Sky), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("روش یادگیری ما", fontWeight = FontWeight.Bold, color = Navy)
                    Text("هر مدخل شامل تلفظ آمریکایی، معنی فارسی، تعریف ساده انگلیسی، مثال، خانواده کلمات، مترادف‌ها و متضادهاست.",
                        color = Ink, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun VocabularyScreen(query: String, onQuery: (String) -> Unit, onSelect: (Word) -> Unit) {
    Column {
        Header("فرهنگ لغت", "جستجو در واژگان کاربردی انگلیسی آمریکایی")
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text("جستجوی انگلیسی یا معنی فارسی") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            items(words.filter { query.isBlank() || it.word.contains(query, true) || it.meaning.contains(query) }) { word ->
                Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onSelect(word) },
                    colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(word.word, color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text(word.meaning, color = Ink, fontSize = 14.sp)
                            Text("${word.pos}  •  ${word.ipa}", color = Blue, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Blue)
                    }
                }
            }
        }
    }
}

@Composable
fun WordDetail(word: Word, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(16.dp))
            Text("جزئیات واژه", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.padding(16.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Sky), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(word.word.uppercase(), color = Navy, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("${word.ipa}   •   ${word.persianSound}", color = Blue)
                        Text("${word.pos}  |  ${word.meaning}", color = Ink, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(word.definition, color = Ink)
                        Spacer(Modifier.height(12.dp))
                        Text(word.example, color = Navy, fontWeight = FontWeight.Bold)
                        Text(word.exampleFa, color = Ink)
                    }
                }
            }
            item { RelationSection("خانواده کلمات (Word Family)", word.family, Mint) }
            item { RelationSection("مترادف‌ها (Synonyms)", word.synonyms, Color(0xFFFFF1E8)) }
            item { RelationSection("متضادها (Antonyms)", word.antonyms, Color(0xFFFFE9ED)) }
        }
    }
}

@Composable
fun RelationSection(title: String, entries: List<Pair<String,String>>, bg: Color) {
    if (entries.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp)) {
                Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                entries.forEach { (term, meaning) ->
                    Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(term, color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(meaning, color = Ink, textAlign = TextAlign.End)
                    }
                }
            }
        }
    }
}

@Composable
fun GrammarScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("آکادمی گرامر", "آموزش مرحله‌به‌مرحله از صفر تا پیشرفته")
        val lessons = listOf(
            "01  ساختار جمله در انگلیسی" to "Sentence Structure",
            "02  ضمایر و فعل to be" to "Pronouns & Be",
            "03  حال ساده" to "Present Simple",
            "04  حال استمراری" to "Present Continuous",
            "05  گذشته ساده" to "Past Simple",
            "06  آینده و شکل‌های بیان آینده" to "Future Forms",
            "07  حروف اضافه پرکاربرد" to "Prepositions",
            "08  افعال کمکی" to "Modal Verbs",
            "09  جملات شرطی" to "Conditionals",
            "10  مجهول" to "Passive Voice"
        )
        LazyColumn(Modifier.padding(16.dp)) {
            items(lessons) { lesson ->
                Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("📘", fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(lesson.first, color = Ink, fontWeight = FontWeight.Bold)
                            Text(lesson.second, color = Blue, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, description: String) {
    Column(Modifier.fillMaxSize()) {
        Header(title)
        Card(Modifier.padding(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Text(description, Modifier.padding(20.dp), color = Ink)
        }
    }
}
